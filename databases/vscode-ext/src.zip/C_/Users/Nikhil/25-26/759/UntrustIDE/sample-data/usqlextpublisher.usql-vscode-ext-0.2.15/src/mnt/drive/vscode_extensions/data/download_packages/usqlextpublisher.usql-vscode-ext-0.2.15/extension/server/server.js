/// <disable>JS2085</disable>
'use strict';
/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */
var vscode_languageserver_1 = require('vscode-languageserver');
var util_1 = require('./features/util');
var doccontents_1 = require('./features/doccontents');
var http = require('http');
var protocol_1 = require('./protocol');
var docsChange = {};
// Create a connection for the server. The connection uses Node's IPC as a transport
var connection = vscode_languageserver_1.createConnection(new vscode_languageserver_1.IPCMessageReader(process), new vscode_languageserver_1.IPCMessageWriter(process));
var content;
var symbolTypeMap = {
    'KeyWord': vscode_languageserver_1.CompletionItemKind.Keyword,
    'Method': vscode_languageserver_1.CompletionItemKind.Method,
    'ClassName': vscode_languageserver_1.CompletionItemKind.Class,
    'Field': vscode_languageserver_1.CompletionItemKind.Field,
    'FunctionName': vscode_languageserver_1.CompletionItemKind.Function,
    'ModuleName': vscode_languageserver_1.CompletionItemKind.Module,
    'Property': vscode_languageserver_1.CompletionItemKind.Property
};
var symbolTypeDic = {
    'TypeCode20': vscode_languageserver_1.CompletionItemKind.Keyword,
    'TypeCode50': vscode_languageserver_1.CompletionItemKind.Method,
    'TypeCode30': vscode_languageserver_1.CompletionItemKind.Class,
    'TypeCode60': vscode_languageserver_1.CompletionItemKind.Field,
    'TypeCode98': vscode_languageserver_1.CompletionItemKind.Function,
    'TypeCode99': vscode_languageserver_1.CompletionItemKind.Module,
    'TypeCode70': vscode_languageserver_1.CompletionItemKind.Property
};
// Create a simple text document manager. The text document manager
// supports full document sync only
var documents = new vscode_languageserver_1.TextDocuments();
// Make the text document manager listen on the connection
// for open, change and close text document events
documents.listen(connection);
// After the server has started the client sends an initilize request. The server receives
// in the passed params the rootPath of the workspace plus the client capabilites. 
var workspaceRoot;
connection.onInitialize(function (params) {
    workspaceRoot = params.rootPath;
    return {
        capabilities: {
            // Tell the client that the server works in FULL text document sync mode
            textDocumentSync: documents.syncKind,
            // Tell the client that the server support code complete
            completionProvider: {
                resolveProvider: true
            }
        }
    };
});
// The content of a text document has changed. This event is emitted
// when the text document first opened or when its content has changed.
documents.onDidChangeContent(function (change) {
    connection.console.log("[Server] onDidChangeContent emmited " + change.document.uri);
    if (change.document.uri.lastIndexOf('.usql') + '.usql'.length != change.document.uri.length) {
        return;
    }
    validateTextDocument(change.document);
    docsChange[change.document.uri] = new doccontents_1.DocContent({
        Position: 1,
        Content: change.document.getText(),
        TextDocument: null
    });
});
// hold the maxNumberOfProblems setting
var maxNumberOfProblems;
var languageWrapperPort;
// The settings have changed. Is send on server activation
// as well.
connection.onDidChangeConfiguration(function (change) {
    var settings = change.settings;
    maxNumberOfProblems = settings.usqlLanguageServer.maxNumberOfProblems || 100;
    languageWrapperPort = settings.usqlLanguageServer.languageWrapperPort || 12342;
    // Revalidate any open text document
    documents.all().forEach(validateTextDocument);
});
function validateTextDocument(textDocument) {
    var filePath = util_1.util.ConvertUriToPath(textDocument.uri);
    var content = textDocument.getText();
    var payload = {
        Path: filePath,
        Source: content
    };
    var diagnostics = [];
    callScopeCompilerWrapper(payload, '/GetErrorList', function (output) {
        connection.console.log(output);
        if (output != null) {
            output.forEach(function (e) {
                diagnostics.push({
                    severity: vscode_languageserver_1.DiagnosticSeverity.Error,
                    range: {
                        start: { line: e.Location.sLin, character: e.Location.sIndex },
                        end: { line: e.Location.eLin, character: e.Location.eIndex }
                    },
                    message: e.Message,
                    source: 'ex'
                });
            });
            connection.sendDiagnostics({ uri: textDocument.uri, diagnostics: diagnostics });
        }
    });
    // Send the computed diagnostics to VSCode.
}
function getPositionOffset(content, position) {
    var lines = content.split(/\r?\n/g);
    var currentPositionOffset = 0;
    for (var i = 0; i < position.line; i++) {
        // For Windows, \r\n would take 2 characters and for Linux  \r will only take 1 character.
        switch (process.platform) {
            case 'win32':
                currentPositionOffset += lines[i].length + 2;
                break;
            default:
                currentPositionOffset += lines[i].length + 1;
        }
    }
    currentPositionOffset += position.character;
    return currentPositionOffset - 1;
}
connection.onDidChangeWatchedFiles(function (change) {
    // Monitored files have change in VSCode
    connection.console.log('[Server] We recevied an file change event');
});
// This handler provides the initial list of the completion items.
connection.onCompletion(function (textDocumentPosition) {
    // The pass parameter contains the position of the text document in 
    // which code complete got requested. For the example we ignore this
    // info and always provide the same completion items.
    connection.console.log("[Server] convert USQL Path: " + textDocumentPosition.textDocument.uri);
    var usqlScriptPath = util_1.util.ConvertUriToPath(textDocumentPosition.textDocument.uri);
    connection.console.log("[Server] convert USQL Path: " + usqlScriptPath);
    var content = docsChange[textDocumentPosition.textDocument.uri];
    var textDocument = documents.get(textDocumentPosition.textDocument.uri);
    var offsetPosition = textDocument.offsetAt(textDocumentPosition.position);
    var postData = {
        Path: usqlScriptPath,
        Source: content.Content,
        Start: getPositionOffset(content.Content, textDocumentPosition.position).toString()
    };
    connection.console.log("[Server] path=" + postData.Path + ", start=" + postData.Start + ", source=" + postData.Source);
    var completionList = [];
    connection.console.log('[Server] Start getting completion list');
    return new Promise(function (resolve, reject) {
        callScopeCompilerWrapperSyncPromise(postData, '/GetCompletionList').then(function (output) {
            connection.console.log(output);
            var completionList = [];
            var i = 1;
            if (output != null) {
                output.forEach(function (element) {
                    var typeCode = 'TypeCode' + element.Type.toString();
                    if (symbolTypeDic[typeCode] != null) {
                        completionList.push({
                            label: element.Text,
                            kind: symbolTypeDic[typeCode],
                            data: i,
                            detail: element.Description
                        });
                    }
                    else {
                        completionList.push({
                            label: element.Text,
                            kind: vscode_languageserver_1.CompletionItemKind.Reference,
                            data: i,
                            detail: element.Description,
                        });
                    }
                    i = i + 1;
                });
            }
            return resolve(completionList);
        });
    });
});
// This handler resolve additional information for the item selected in
// the completion list.
connection.onCompletionResolve(function (item) {
    //item.detail = item.label;
    item.documentation = item.label;
    return item;
});
connection.onRequest(protocol_1.AccountStatusRequest.type.method, function (params) {
    connection.console.log("[Server] Request received " + params.status);
    if (params.status == 'shutdown') {
        var payload = {
            'action': 'shutdown'
        };
        callScopeCompilerWrapperSyncPromise(payload, '/Shutdown');
    }
    var result = {
        result: 'result'
    };
    return result;
});
connection.onRequest(protocol_1.CatalogServiceUpdateRequest.type.method, function (params) {
    connection.console.log("[Server] CatalogServiceUpdateRequest received: port= " + params.port + ", workingFolder=" + params.workingFolder + ", ComputeAccount=" + params.computeAccount);
    if (params.computeAccount == null || params.port == null || params == null) {
        connection.console.log('[Server] params null detected, pass');
        return;
    }
    var payload = {
        Port: params.port.toString(),
        WorkingFolder: params.workingFolder
    };
    callScopeCompilerWrapper(payload, '/SetCatalogServiceHelper', function (output) {
        connection.console.log(output);
    });
    var nameContextManagerPayLoad = {
        ComputeAccount: params.computeAccount,
        Database: 'master',
        Schema: 'dbo'
    };
    callScopeCompilerWrapper(nameContextManagerPayLoad, '/SetNameContextManagerConsole', function (output) {
        connection.console.log(output);
    });
    var updateResult = {
        result: 'success'
    };
    return updateResult;
});
/*
connection.onDidOpenTextDocument((params) => {
    // A text document got opened in VSCode.
    // params.uri uniquely identifies the document. For documents store on disk this is a file URI.
    // params.text the initial full content of the document.
});*/
/*
connection.onDidChangeTextDocument((params) => {
    // The content of a text document did change in VSCode.
    // params.uri uniquely identifies the document.
    // params.contentChanges describe the content changes to the document.
    //connection.console.log(`${params.textDocument.uri} changed: ${JSON.stringify(params.contentChanges)}`);
    docsChange[params.textDocument.uri] = new DocContent({
        Position: 1,
        Content: params.contentChanges[0].text,
        TextDocument: null
    });
});*/
/*
connection.onDidCloseTextDocument((params) => {
    // A text document got closed in VSCode.
    // params.uri uniquely identifies the document.
    connection.console.log(`${params.uri} closed.`);
});
*/
function callScopeCompilerWrapper(postData, action, callback) {
    var postDataStr = JSON.stringify(postData);
    var options = {
        port: languageWrapperPort,
        path: action,
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength((postDataStr))
        }
    };
    var req = http.request(options, function (res) {
        res.setEncoding('utf8');
        var output = '';
        res.on('data', function (chunk) {
            output += chunk;
        });
        res.on('end', function () {
            var resultObject = JSON.parse(output);
            if (callback) {
                callback(resultObject);
            }
        });
    });
    req.on('error', function (e) {
        connection.console.log("[Server] problem with request: " + e.message);
    });
    // write data to request body
    req.write(postDataStr);
    req.end();
}
function callScopeCompilerWrapperSyncPromise(postData, action) {
    return new Promise(function (resolve, reject) {
        var postDataStr = JSON.stringify(postData);
        var options = {
            port: languageWrapperPort,
            path: action,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength((postDataStr))
            }
        };
        var req = http.request(options, function (res) {
            res.setEncoding('utf8');
            var output = '';
            res.on('data', function (chunk) {
                output += chunk;
            });
            res.on('end', function () {
                var resultObject = JSON.parse(output);
                connection.console.log(resultObject);
                return resolve(resultObject);
            });
        });
        req.on('error', function (e) {
            connection.console.log("[Server] problem with request: " + e.message);
        });
        // write data to request body
        req.write(postDataStr);
        req.end();
    }).catch(function (err) {
        return null;
    });
}
function getCompletionList() {
    return new Promise(function (resolve, reject) {
        var completionList = [];
        completionList.push({
            label: 'ss',
            kind: vscode_languageserver_1.CompletionItemKind.Class,
            data: 1
        });
        return resolve(completionList);
    });
}
// Listen on the connection
connection.listen();
//# sourceMappingURL=server.js.map