/// <disable>JS2085</disable>
'use strict';
var AccountStatusRequest;
(function (AccountStatusRequest) {
    AccountStatusRequest.type = {
        get method() { return 'getstatus'; }
    };
})(AccountStatusRequest = exports.AccountStatusRequest || (exports.AccountStatusRequest = {}));
var CatalogServiceUpdateRequest;
(function (CatalogServiceUpdateRequest) {
    CatalogServiceUpdateRequest.type = {
        get method() { return 'updatecatalogservice'; }
    };
})(CatalogServiceUpdateRequest = exports.CatalogServiceUpdateRequest || (exports.CatalogServiceUpdateRequest = {}));
;
var ComputeAccountUpdateRequest;
(function (ComputeAccountUpdateRequest) {
    ComputeAccountUpdateRequest.type = {
        get method() { return 'updatecatalogservice'; }
    };
})(ComputeAccountUpdateRequest = exports.ComputeAccountUpdateRequest || (exports.ComputeAccountUpdateRequest = {}));
;
var MessageRequest;
(function (MessageRequest) {
    MessageRequest.type = {
        get method() { return 'sendlanguagemessage'; }
    };
})(MessageRequest = exports.MessageRequest || (exports.MessageRequest = {}));
;
//# sourceMappingURL=protocol.js.map